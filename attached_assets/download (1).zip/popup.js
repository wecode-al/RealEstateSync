chrome.tabs.query({active: true, currentWindow: true}, function (tabs) {
    const current_url = tabs[0].url
    const platform = getPlatform(current_url);

    if (platform && platform.length) {
        const content = document.getElementById('content');
        const connectionText = document.createElement('p');
        connectionText.innerText = `Kliko butonin Connect për të lidhur ${platform[0]} me Agjentin`;
        content.appendChild(connectionText);

        chrome.cookies.getAll({url: current_url}, function (cookies) {
            const cookieData = cookies.map(cookie => ({
                name: cookie.name,
                value: cookie.value,
                expirationDate: cookie.expirationDate
            }));

            const agjentiUrl = `https://agjenti.al/connect-by-extension?platform=${platform[1]}&cookies=${JSON.stringify(cookieData)}`;
            chrome.tabs.create({url: agjentiUrl});
        });
    } else {
        document.getElementById('content').innerHTML = '<p>Extension-i funksionon vetëm për faqet gazeta celesi, merrjep, njoftime falas, njoftime.com dhe njoftime.al</p>';
    }
});

function getPlatform(url) {
    if (url.includes('https://www.merrjep.al')) {
        return ['Merrjep', 'merrjep'];
    } else if (url.includes('https://www.njoftime.al')) {
        return ['Njoftime.al', 'njoftime'];
    } else if (url.includes('https://www.njoftimefalas.com')) {
        return ['Njoftime Falas', 'njoftime_falas'];
    } else if (url.includes('https://www.njoftime.com')) {
        return ['Njoftime.com', 'njoftime_com'];
    } else if (url.includes('https://new-stg.gazetacelesi.al/')) {
        return ['Gazeta Celesi', 'gazeta_celesi_al'];
    }
}
